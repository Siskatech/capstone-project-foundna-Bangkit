package com.example.foundna_app

import org.tensorflow.lite.support.image.TensorImage

data class Petshop(val image:Int, val name:String)
